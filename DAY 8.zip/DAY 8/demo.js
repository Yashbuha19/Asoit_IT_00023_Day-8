let x=5,y=4;
var z=x+y;
var a=x-y;
var b=x*y;
var c=x/y;
console.log("sum of x and y is:",z,"\n");
document.write(z,"\n");
document.write(a,"\n");
document.write(b,"\n");
document.write(c,"\n");
var Num=100;
var str="swati solanki";
var BooleanVar=true;

document.write("<br/>",Num);
document.write("<br/>",str);
document.write("<br/>",BooleanVar);
document.write("<br/>",typeof(Num));
document.write("<br/>",typeof(Str));
document.write("<br/>",typeof(BooleanVar));
var car ={
    modal: "bmw",
    color: "white",
    doors: 5
}
document.write("<br/>"+car.modal+" "+car.color+" "+car.doors);

var cars = ["bmw", "mercedes-benz", "volkswagen"];
document.write("<br/>"+cars[0]);
document.write("<br/>"+cars[1]);
document.write("<br/>"+cars[2]);

var Demo = function(){
    return "hello welcome to javascript!";
}
document.write("<br/>"+typeof(Demo));
document.write("<br/>"+Demo());